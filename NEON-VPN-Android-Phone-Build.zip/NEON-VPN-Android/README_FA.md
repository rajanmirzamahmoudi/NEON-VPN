# NEON VPN — پروژه اندروید

این پروژه یک کلاینت اندرویدی WireGuard با رابط فارسی/نئونی است.

## امکانات
- استفاده از کتابخانه رسمی WireGuard Tunnel برای اندروید
- واردکردن فایل تنظیمات `.conf` از حافظه دستگاه
- درخواست مجوز VPN از خود اندروید
- اتصال و قطع واقعی تونل با `GoBackend`
- نمایش وضعیت اتصال بر اساس نتیجه واقعی backend

## نکته مهم درباره سرور رایگان
این برنامه سرور VPN یا حساب رایگان ارائه نمی‌کند. برای اتصال واقعی باید فایل `.conf` معتبر از یک ارائه‌دهنده سرور WireGuard داشته باشید. فایل کانفیگ معمولاً شامل کلید خصوصی است؛ آن را خصوصی نگه دارید. از کانفیگ ناشناس یا منبع نامطمئن استفاده نکنید.

## ساخت APK
1. Android Studio را نصب و این پوشه را با گزینه **Open** باز کنید.
2. اجازه دهید Gradle Sync کامل شود و وابستگی WireGuard از Maven Central دریافت شود.
3. از منوی **Build → Build Bundle(s) / APK(s) → Build APK(s)** خروجی بگیرید.
4. فایل Debug APK در مسیر `app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.

نیازمندی‌ها: JDK 17، Android SDK Platform 36، Android Gradle Plugin 8.13.2 و Gradle 8.13.

## وابستگی اصلی
`com.wireguard.android:tunnel:1.0.20260102`

صفحه رسمی کتابخانه: https://central.sonatype.com/artifact/com.wireguard.android/tunnel
مستندات پروژه WireGuard Android: https://github.com/WireGuard/wireguard-android
