package com.neonvpn.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.Toast
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.config.Config
import com.wireguard.android.backend.Tunnel
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var backend: Backend
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var importButton: Button
    private lateinit var connectButton: Button
    private lateinit var disconnectButton: Button
    private var activeConfig: Config? = null
    private var tunnel: AppTunnel? = null
    private var busy = false

    private val pickConfig = 1001
    private val requestVpnPermission = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(applicationContext)
        buildUi()
        refreshUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(20))
            setBackgroundColor(Color.rgb(7, 11, 22))
        }
        val scroll = ScrollView(this).apply { addView(root) }

        val brand = TextView(this).apply {
            text = "NEON VPN"
            textSize = 29f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        root.addView(brand, matchWrap())
        root.addView(label("PRIVATE CONNECTION • WIREGUARD", 11f, CYAN, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, dp(28))
        }, matchWrap())

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(26), dp(18), dp(26))
            background = rounded("#101B30", 24, "#16415B")
        }
        status = label("DISCONNECTED", 22f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        panel.addView(status, matchWrap())
        details = label("وضعیت: آماده\nابتدا فایل تنظیمات WireGuard را وارد کن", 14f, MUTED, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(10))
        }
        panel.addView(details, matchWrap())
        root.addView(panel, matchWrap().apply { bottomMargin = dp(22) })

        importButton = actionButton("وارد کردن فایل کانفیگ (.conf)", CYAN)
        importButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(intent, pickConfig)
        }
        root.addView(importButton, matchWrap().apply { bottomMargin = dp(12) })

        connectButton = actionButton("اتصال امن", "#126B91")
        connectButton.setOnClickListener { connect() }
        root.addView(connectButton, matchWrap().apply { bottomMargin = dp(12) })

        disconnectButton = actionButton("قطع اتصال", "#29364B")
        disconnectButton.setOnClickListener { disconnect() }
        root.addView(disconnectButton, matchWrap().apply { bottomMargin = dp(24) })

        val note = label(
            "نکته: این برنامه سرور رایگان تولید نمی‌کند. برای اتصال، به فایل معتبر WireGuard از ارائه‌دهنده‌ای که به آن اعتماد داری نیاز است. فایل کانفیگ شامل کلید خصوصی است؛ آن را با دیگران به اشتراک نگذار.\n\nNEON VPN فقط از تونل WireGuard استفاده می‌کند و تا وقتی اتصال موفق نشود، وضعیت را متصل نشان نمی‌دهد.",
            12f, MUTED, false
        )
        root.addView(note, matchWrap())
        setContentView(scroll)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickConfig && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val text = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalArgumentException("فایل خوانده نشد")
                val parsed = Config.parse(ByteArrayInputStream(text))
                activeConfig = parsed
                tunnel = AppTunnel("NEON")
                details.text = "کانفیگ معتبر بارگذاری شد\nآماده اتصال به سرور تنظیم‌شده در فایل"
                refreshUi()
                toast("فایل کانفیگ با موفقیت خوانده شد")
            } catch (e: Exception) {
                activeConfig = null
                tunnel = null
                details.text = "فایل کانفیگ معتبر نیست یا قابل خواندن نیست"
                refreshUi()
                toast("خطا در فایل: ${e.message ?: "فرمت نامعتبر"}")
            }
        } else if (requestCode == requestVpnPermission && resultCode == RESULT_OK) {
            startTunnel()
        } else if (requestCode == requestVpnPermission) {
            toast("مجوز VPN داده نشد")
        }
    }

    private fun connect() {
        if (busy) return
        if (activeConfig == null || tunnel == null) {
            toast("اول فایل کانفیگ WireGuard را وارد کن")
            return
        }
        val permissionIntent = VpnService.prepare(this)
        if (permissionIntent != null) startActivityForResult(permissionIntent, requestVpnPermission)
        else startTunnel()
    }

    private fun startTunnel() {
        val config = activeConfig ?: return
        val selectedTunnel = tunnel ?: return
        setBusy(true, "در حال اتصال…")
        executor.execute {
            try {
                backend.setState(selectedTunnel, Tunnel.State.UP, config)
                runOnUiThread {
                    setBusy(false, "CONNECTED")
                    details.text = "تونل WireGuard فعال است\nترافیک از کانفیگ انتخاب‌شده عبور می‌کند"
                    refreshUi()
                    toast("اتصال برقرار شد")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false, "اتصال برقرار نشد")
                    details.text = "اتصال ناموفق بود. سرور، اینترنت و کانفیگ را بررسی کن.\n${e.message ?: "خطای ناشناخته"}"
                    refreshUi()
                    toast("اتصال ناموفق بود")
                }
            }
        }
    }

    private fun disconnect() {
        val selectedTunnel = tunnel
        if (selectedTunnel == null || busy) {
            if (selectedTunnel == null) toast("هنوز تونلی فعال نیست")
            return
        }
        setBusy(true, "در حال قطع اتصال…")
        executor.execute {
            try {
                backend.setState(selectedTunnel, Tunnel.State.DOWN, null)
                runOnUiThread {
                    setBusy(false, "DISCONNECTED")
                    details.text = "اتصال قطع شد"
                    refreshUi()
                    toast("اتصال قطع شد")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false, "خطا در قطع اتصال")
                    details.text = e.message ?: "خطای ناشناخته"
                    refreshUi()
                }
            }
        }
    }

    private fun setBusy(value: Boolean, message: String) {
        busy = value
        status.text = message
        refreshUi()
    }

    private fun refreshUi() {
        if (!::connectButton.isInitialized) return
        val up = tunnel?.let { try { backend.getState(it) == Tunnel.State.UP } catch (_: Exception) { false } } ?: false
        importButton.isEnabled = !busy && !up
        connectButton.isEnabled = !busy && !up && activeConfig != null
        disconnectButton.isEnabled = !busy && up
        if (!busy) status.text = if (up) "CONNECTED" else "DISCONNECTED"
        status.setTextColor(if (up) CYAN else Color.WHITE)
        importButton.alpha = if (importButton.isEnabled) 1f else .5f
        connectButton.alpha = if (connectButton.isEnabled) 1f else .5f
        disconnectButton.alpha = if (disconnectButton.isEnabled) 1f else .5f
    }

    private fun actionButton(text: String, color: String) = Button(this).apply {
        this.text = text
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(color, 16)
        minHeight = dp(54)
    }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun rounded(fill: String, radius: Int, stroke: String? = null): GradientDrawable = GradientDrawable().apply {
        setColor(Color.parseColor(fill))
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), Color.parseColor(stroke))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }

    private class AppTunnel(private val tunnelName: String) : Tunnel {
        @Volatile private var currentState = Tunnel.State.DOWN
        override fun getName(): String = tunnelName
        override fun onStateChange(newState: Tunnel.State) { currentState = newState }
    }

    companion object {
        private val CYAN = Color.rgb(32, 223, 255)
        private val MUTED = Color.rgb(151, 174, 201)
    }
}
